﻿using System;

namespace Zanzibar
{
    class Program
    {
        static void Main(string[] args)
        {


        }

        static void ComptePointsDe(int de, out int points)
        {
            if (de == 1)
            {
                points = 100;
            } else
            {
                if (de >= 2 && de <= 5 )
                {
                    points = de;
                } else
                {
                    points = 60;
                }
            }
        }

        static void TourDeJeu(out string desSortis, out int pointsTour, out bool arret)
        {
            desSortis = "";
            pointsTour = 0;
            arret = false;
            int compte2;
            compte2 = 0;
            Random alea = new Random();
            for (int i = 1; i < 2; i++)
            {
                desSortis = alea.Next(1, 7);
                if (desSortis = 2)
                {
                    compte2 = compte2 + 1;
                }
                desSortis = desSortis + de + " ";
                comptePointsDe(desSortis, out points);
                pointsTour = pointsTour + points;

            }

            if (compte2 == 3)
            {
                arret = true;
            };


        }
    }
}
